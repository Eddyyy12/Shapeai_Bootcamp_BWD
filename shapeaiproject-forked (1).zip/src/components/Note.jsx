import React from "react";

function Note(){
  return (
    <div className="note"> 
      <h1> Javascript and React.js </h1>
      <p> This was an amazing boootcamp taken up by Shaurya
Sinha . We covered everything from scratch including javascript ,React.js,HTML.         
        </p> 
    </div>
  );
}
export default Note;